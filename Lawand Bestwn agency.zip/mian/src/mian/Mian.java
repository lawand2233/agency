/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mian;

/**
 *
 * @author HP
 */
public class Mian {
    public static void main(String[] args) {
        RealEstateagency agency = new RealEstateagency();

        Villa villa = new Villa(250, 5, "Downtown", 500000, true, 3);
        Apartment apartment = new Apartment(120, 3, "Uptown", 200000, 5, true);
              FurnishedApartment furnishedApartment = new FurnishedApartment(90, 2, "Suburbs", 150000, 2, false, 3);

    agency.addProperty(villa);
    agency.addProperty(apartment);
     agency.addProperty(furnishedApartment);

        agency.displayAllProperties();
    }
}

