/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mian;

/**
 *
 * @author HP
 */
public class property {
    private double area;
    private int numOfRooms;
    private String neighborhood;
    private double price;

    public property(double area, int numOfRooms, String neighborhood, double price) {
        this.area = area;
        this.numOfRooms = numOfRooms;
        this.neighborhood = neighborhood;
        this.price = price;
    }

    public void display() {
        System.out.println("Type: Property");
        System.out.println("Area: " + area + " m2");
        System.out.println("Number of Rooms: " + numOfRooms);
        System.out.println("Neighborhood: " + neighborhood);
        System.out.println("Price: $" + price);
    }
}

    

