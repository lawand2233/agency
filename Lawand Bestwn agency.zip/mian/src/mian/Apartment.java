/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mian;


 public class Apartment extends property {
    private int floor;
    private boolean hasParking;

    public Apartment(double area, int numOfRooms, String neighborhood, double price, int floor, boolean hasParking) {
        super(area, numOfRooms, neighborhood, price);
        this.floor = floor;
        this.hasParking = hasParking;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Floor: " + floor);
        System.out.println("Has Parking Lot: " + (hasParking ? "Yes" : "No"));
    }
}

