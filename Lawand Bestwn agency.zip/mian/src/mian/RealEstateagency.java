/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mian;

/**
 *
 * @author HP
 */
import java.util.ArrayList;

public class RealEstateagency {
    private ArrayList<property> properties;

    public RealEstateagency() {
        properties = new ArrayList<>();
    }

    public boolean addProperty(property property) {
        if (properties.size() < 100) {
            properties.add(property);
            return true;
        }
        return false;
    }

    public boolean removeProperty(property property) {
        return properties.remove(property);
    }

    public void displayAllProperties() {
        for (property property : properties) {
            property.display();
            System.out.println("------------");
        }
    }
}

