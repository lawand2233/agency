/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mian;

/**
 *
 * @author HP
 */
public class FurnishedApartment extends Apartment {
    private int furnitureQuality;

    public FurnishedApartment(double area, int numOfRooms, String neighborhood, double price, int floor, boolean hasParking, int furnitureQuality) {
        super(area, numOfRooms, neighborhood, price, floor, hasParking);
        this.furnitureQuality = furnitureQuality;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Furniture Quality: " + furnitureQuality + " (1=Best, 5=Worst)");
    }
}

