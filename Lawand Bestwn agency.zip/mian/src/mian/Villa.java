/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mian;

/**
 *
 * @author HP
 */
public class Villa extends property {
    private boolean hasSwimmingPool;
    private int adjacentStreets;

    public Villa(double area, int numOfRooms, String neighborhood, double price, boolean hasSwimmingPool, int adjacentStreets) {
        super(area, numOfRooms, neighborhood, price);
        this.hasSwimmingPool = hasSwimmingPool;
            this.adjacentStreets = adjacentStreets;
    }

@Override
    public void display() {
        super.display();
        System.out.println("Has Swimming Pool: " + (hasSwimmingPool ? "Yes" : "No"));
        System.out.println("Number of Adjacent Streets: " + adjacentStreets);
    }
}

